#!/bin/bash

echo "spawning a popcat"

cd popcat

python cat.py
