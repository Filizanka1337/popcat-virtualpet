echo "Spawning a popcat"
cd "./popcat"
python "cat.py"
